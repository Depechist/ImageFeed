import Foundation

let accessKey = "7NF2WMuQDuREuk7AGo8yMvVBeD9AyLpJjvqe7dCAO7g"
let secretKey = "ilSmfh98pCbjqk8E30ZrygDH3BNQbCZd4nSZUTyyqI8"
let redirectURI = "urn:ietf:wg:oauth:2.0:oob"
let accessScope = "public+read_user+write_likes"
let defaultBaseURL = URL(string: "https://api.unsplash.com")!
